<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>

  <div class="row">
<?php if(auth()->user()->hasRole('admin')): ?>

    <h2>Admin Dashboard</h2>
<?php else: ?>
<h2>User Dashboard</h2>
<?php endif; ?>
<div class="col-md-8 col-md-offset-2">
  <h3>Please check the chekbox to calculate the value</h3>
  <?php for($i=1;$i<5;$i++): ?>
  <div class="checkbox">
    <label>
      <input
      class="bsb-checkbox"
      type="checkbox"
      name="amount[]"
      value="<?php echo e($i*100); ?>"
      > <?php echo e($i*100); ?>

    </label>
  </div>
  <br/>
  <?php endfor; ?>
  <div class="form-group">
    <label>Total:</label><span>&nbsp;<b id="total">0</b></span>

  </div>

</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script>
  let total=0;
  $('.bsb-checkbox').on('change',function(){
    let val=parseInt($(this).val());
         if($(this).is(":checked")){
           total+=val;
         }else{
              total-=val;
          }
    $('#total').text(total)
    
  })

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>