<?php if(session('success_message')): ?>
  <div class="alert alert-success stay">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><span class="material-icons">clear</span></button>
    <p><?php echo session('success_message'); ?></p>
  </div>
<?php elseif(session('failure_message')): ?>
  <div class="alert alert-warning stay">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><span class="material-icons">clear</span></button>
    <p><?php echo session('failure_message'); ?></p>
  </div>
<?php endif; ?>

<?php if(count($errors)): ?>
  <div class="alert stay alert-danger">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><span class="material-icons">clear</span></button>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <p><?php echo $error; ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
<?php endif; ?>
