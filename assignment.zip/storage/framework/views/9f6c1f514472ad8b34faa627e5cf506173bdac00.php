<div class="sidebar"
     data-active-color="rose"
     data-background-color="black"
     data-image="<?php echo e(material_dashboard_url('img/sidebar-3.jpg')); ?>">

  
  <div class="sidebar-wrapper">
    <div class="user">
      <div class="photo">
       
      </div>
      <div class="info">
        <a data-toggle="collapse" href="#collapseExample" class="collapsed">
          <span>
              <?php echo e(auth()->user()->name); ?>

            <b class="caret"></b>
          </span>
        </a>
        <div class="clearfix"></div>
        <div class="collapse"
             id="collapseExample">
          <ul class="nav">
            <li <?php if(request()->is('admin/my-profile')): ?> class="active" <?php endif; ?>>
              <a href="">
                <span class="sidebar-mini">&nbsp;</span>
                <span class="sidebar-normal">My Profile</span>
              </a>
            </li>
            
            <li>
              <a href="<?php echo e(url('/logout')); ?>"
                 onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                <span class="sidebar-mini">&nbsp;</span>
                <span class="sidebar-normal">Logout</span>
              </a>
              <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                <?php echo e(csrf_field()); ?>

              </form>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <ul class="nav">
     <?php if(auth()->user()->hasRole('admin') || auth()->user()->hasRole('normal')): ?>
        
        <li <?php if(request()->is('admin/product*')): ?> class="active" <?php endif; ?>>
          <a data-toggle="collapse" href="#product">
           <i class="fa fa-shopping-bag"></i>
            <p><?php echo e(ucfirst('product')); ?>

              <b class="caret"></b>
            </p>
          </a>
          <div class="collapse <?php if(request()->is('admin/product*')): ?> in <?php endif; ?>" id="product">
            <ul class="nav">
              <li <?php if(request()->is('admin/product')): ?> class="active" <?php endif; ?>>
                <a href="<?php echo e(route('product.index')); ?>">
                  <span class="sidebar-mini">A</span>
                  <span class="sidebar-normal">All <?php echo e(ucfirst(str_plural('product'))); ?></span>
                </a>
              </li>
              <li <?php if(request()->is('admin/product/create')): ?> class="active" <?php endif; ?>>
                <a href="<?php echo e(route('product.create')); ?>">
                  <span class="sidebar-mini">N</span>
                  <span class="sidebar-normal">New <?php echo e(ucfirst('product')); ?></span>
                </a>
              </li>
            </ul>
          </div>
        </li>
        
  <?php endif; ?>

  <?php if(auth()->user()->hasRole('admin')): ?>

  
  <li <?php if(request()->is('admin/user*')): ?> class="active" <?php endif; ?>>
    <a data-toggle="collapse" href="#news">
      <i class="material-icons">dvr</i>
      <p><?php echo e(ucfirst('users')); ?>

        <b class="caret"></b>
      </p>
    </a>
    <div class="collapse <?php if(request()->is('admin/user*')): ?> in <?php endif; ?>" id="news">
      <ul class="nav">
        <li <?php if(request()->is('admin/user')): ?> class="active" <?php endif; ?>>
          <a href="<?php echo e(route('user.index')); ?>">
            <span class="sidebar-mini">&nbsp;</span>
            <span class="sidebar-normal">All <?php echo e(ucfirst(str_plural('users'))); ?></span>
          </a>
        </li>
        
      </ul>
    </div>
  </li>
  


  


  <?php endif; ?>

        

      

      

        

        


      

     

    </ul>
  </div>
</div>