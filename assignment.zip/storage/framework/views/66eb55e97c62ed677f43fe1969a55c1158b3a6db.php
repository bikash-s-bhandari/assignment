<?php $__env->startSection('title', 'All '. ucwords(str_plural($routeType))); ?>

<?php $__env->startSection('content'); ?>
  <div class="card">
    <?php echo $__env->make('extras.index_header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="card-content">



          <div class="table-responsive">
            <table class="table table-shopping" id="product_table">
              <thead>
              <tr>
                <th width="40">SN.</th>
                <th>Name</th>
               

                <th width="80">Actions</th>
              </tr>
              </thead>

            </table>
          </div>






    </div>

  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script type="text/javascript">
$(document).ready(function(){
     $('#product_table').DataTable({
        processing: true,
        serverSide: true,
        ajax: '<?php echo e(route('product.index')); ?>',
        columns: [
            {title:'SN',
                 render: function( data, type, full, meta ) {
                        return meta.row+1;
                    }
            },
            {data: 'name', name: 'name'},
           
            {data: 'action', name: 'action', orderable: true, searchable: true}


        ],
            initComplete: function () {
            this.api().columns().every(function () {
                var column = this;
                var input = document.createElement("input");
                $(input).appendTo($(column.footer()).empty())
                .on('change', function () {
                    column.search($(this).val(), false, false, true).draw();
                });
            });
        }
    });

 });


</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>