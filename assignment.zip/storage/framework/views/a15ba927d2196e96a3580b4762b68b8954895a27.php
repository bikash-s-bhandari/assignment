<?php $__env->startSection('title', 'All '. ucwords(str_plural($routeType))); ?>

<?php $__env->startSection('content'); ?>
  <div class="card">
    <?php echo $__env->make('extras.index_header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="card-content">



          <div class="table-responsive">
            <table class="table table-shopping" id="user_table">
              <thead>
              <tr>
                <th width="40">SN.</th>
                <th>Name</th>
                <th>Email Address</th>
                <th width="80">Actions</th>
              </tr>
              </thead>
              <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <tr id="asdh-<?php echo e($v->id); ?>">
                    <td><?php echo e($key+1); ?></td>
                    
                    <td><?php echo e($v->name); ?></td>
                    <td><?php echo e($v->email); ?></td>

                    <td>
                       <?php echo $__env->make('admin.user.options',['user'=>$v], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </td>
                   
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <tr>
                    <td colspan="4">No data available</td>
                  </tr>
                <?php endif; ?>
                </tbody>

            </table>
          </div>






    </div>

    

  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script type="text/javascript">
$(document).ready(function(){
    $('table').dataTable({
          "paging": true,
          "lengthChange": true,
          "lengthMenu": [10, 15, 20],
          "searching": true,
          "ordering": true,
          "info": false,
          "autoWidth": false,
          'columnDefs': [{
          'orderable': false,
          'targets': [2]
          }]
    });

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>