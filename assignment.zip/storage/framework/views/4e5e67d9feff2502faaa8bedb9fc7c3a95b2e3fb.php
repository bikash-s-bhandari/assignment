<?php $__env->startSection('title', 'Add a new '. ucfirst($routeType)); ?>

<?php $__env->startSection('content'); ?>

  <form action="<?php echo e($edit?route($routeType.'.update',$model):route($routeType.'.store')); ?>"
        method="post"
        enctype="multipart/form-data"
        id="product_validation">
    <?php echo e(csrf_field()); ?>

    <?php echo e($edit?method_field('PUT'):''); ?>

    <div class="card">

      <div class="card-header card-header-text" data-background-color="green">
        <h4 class="card-title"><?php echo e($edit?'Edit':'Add a New '. ucfirst($routeType)); ?></h4>
      </div>

      <div class="card-content">

       
        

        
        <div class="form-group" <?php echo e($errors->has('name')?'has-error is-focused':''); ?>>
          <label for="name"><?php echo e(ucwords('name')); ?></label>
          <input type="text"
                 class="form-control"
                 id="name"
                 name="name"
                 required="true"
                 value="<?php echo e($edit?old('name')??$model->name:old('name')); ?>"/>



        </div>
        

       

        
        <div class="form-group" <?php echo e($errors->has('description')?'has-error is-focused':''); ?>>
          <label for="address"><?php echo e(ucwords('Description')); ?></label>
          <textarea class="form-control asdh-tinymce"
                        id="description"
                        name="description"
                        rows="10"><?php echo e($edit?$model->description:old('description')); ?></textarea>


        </div>
        



        
        <?php if($edit && $model->images->count()>0): ?>
        
         <div class="image_gallery">
           <div class="row">
             <?php $__currentLoopData = $model->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <div class="col-md-3">
              <img src="<?php echo e($image->getImage()); ?>" alt="<?php echo e($model->name); ?>" class="img-thumbnail">
             </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        </div>
      </div>
      <?php endif; ?>
      
  
          <div class="form-group" >
            <label class="control-label">
                   Images
                    <small></small>
                </label>
               <input id="input-b3" name="images[]" type="file" class="file" multiple
                data-show-upload="false" data-show-caption="true" data-msg-placeholder="Select {files} for upload...">
          </div>
      <!--   </div> -->

     



        
        <div class="form-footer text-right">
          <a href="<?php echo e(route('product.index')); ?>" class="btn btn-default"><i class="fa fa-arrow-circle-left"></i> Back</a>
          <button type="submit" class="btn btn-success btn-fill btn-fill btn-prevent-multiple-submit2"><i class="fa fa-save"></i> <?php echo e($edit?'Update':'Save'); ?></button>
        </div>
        

      </div>

    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php echo $__env->make('extras.tinymce', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script>
    $(document).ready(function () {
      $('#product_validation').validate({
            rules: {
                contact_no: {
                  required: true,
                  maxlength: 14
                }
              },
              submitHandler: function(form) {
              var $buttonToDisable = $('.btn-prevent-multiple-submit2');
              $buttonToDisable.prop('disabled', true);
               $buttonToDisable.html('<i class="fa fa-spinner fa-spin"></i> ' + $buttonToDisable.text());
               form.submit();

               }

        });

    });
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>