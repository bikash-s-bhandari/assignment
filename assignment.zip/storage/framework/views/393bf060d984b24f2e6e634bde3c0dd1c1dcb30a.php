<!doctype html>
<html lang="<?php echo e(config('app.locale')); ?>">

<head>
  <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>

<body>

<div class="wrapper">
  <?php echo $__env->make('admin.layouts.leftSidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="main-panel">
    <?php echo $__env->make('admin.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content">
      <div class="container-fluid">
        <?php echo $__env->make('extras.backend_message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="alert alert-success frontend-message-container"
             style="position: fixed;top: 5px;right: 5px;z-index: 9999;width: 500px;opacity: 0.9;display: none;">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">
            
          </button>
          <p class="frontend-message"></p>
        </div>
        <?php echo $__env->yieldContent('content'); ?>
      </div>
    </div>
    <footer class="footer">
      <div class="container-fluid">
        <p class="copyright pull-right">
          &copy;
           <?php echo e(config('app.name')); ?>

          <script>
            document.write(new Date().getFullYear())
          </script>
        </p>
      </div>
    </footer>
  </div>
</div>

</body>

<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</html>